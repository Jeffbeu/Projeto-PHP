-- Quero Visualizar os bancos de dados existentes 
SHOW DATABASES;
-- CRIAR BANCO DE DADOS 
CREATE DATABASE aulaprojeto;
-- APAGAR BANCO DE DADOS 
DROP DATABASE aulaprojeto;
-- CRIAR TABELA EM BANCO DE DADOS 
CREATE TABLE usuario(
    idusuario int AUTO_INCREMENT primary key,
    email varchar (40) unique,
    nome varchar (40) not null,
    senha varchar (50),
    perfil varchar (20)
);
-- CONECTAR O BANCO QUE EU QUERO TRABALHAR
USE aulaprojeto;
-- VIRSUALIZAR AS TABELAS EXISTENTES
SHOW TABLES;
-- DESCREVER OS DADOS DA TABELA 
DESC usuario;
-- INSERIR INFORMAÇÃO EM UMA TABELA 
insert into usuario values
(null,"adm@adm.com","Emanuel","123","ADM");
-- VIRSUALIZAR DADOS DA TABELA 
SELECT * FROM usuario;

-- INSERIR CRIPTOGRAFIA 
insert into usuario values 
(null, "adm@adm2.com", "Emanuel12",md5("123"),"ADM");