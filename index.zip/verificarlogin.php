<?php
// pegar os dados da tela
$email = $_POST["email"];
$senha = $_POST["senha"];

// echo "E-mail : " .$email;
// echo "<br>Senha: ".$senha;
// Abrir a conecção com bando de dados
// mysql_connect(SERVIDOR, USUARIO, SENHA , BANCO)
$con = mysqli_connect("localhost","root","","aulaprojeto");
// montar a instrução de seleção para ir ao banco
$sql ="select * from usuario where email = '".$email."'and senha = '".$senha."'";

// Executar a instrução
//if (mysqli_query($con,$sql)){
    $resultado = mysqli_query($con,$sql);
    if (mysqli_num_rows ($resultado)==1){
    //echo "Encontrei";
    //redirencionar para página painel que esta dentro da pasta ADM
    echo "<script>";
    echo "location.href='ADM/painel.php'";
    echo "</script>";
    
}else{
    //echo "Não Encontrei";
    echo"<script>";
    echo "location.href='logar.php'";
    echo "</script>";

}

?>

